Cameron Bates
AY250- Homework 0

how to run the script(in IPython):
>> run homework0.py
>> sim = runsim(150)

The current population of bears is in the dictionary sim.bears. This contains each bears age, name, mother, father, sex, and time since mating. The length of the dictionary is the current population size.


Question 1: On average 1302 bears are born in the first 100 years with a sample size of 20. On average 103200 bears are alive at 150 years with a sample size of 5.

Question 2: At a ratio of 70/30 females/males the population dies out rouhgly 4/10 of the time. At lower ratios than this the ratio of surviving populations was too small to accurately determine the smallest ratio at which survival was possible. In theory it should be close to 1/7 or 14.3% based on the average bear being able to have 7 cubs in it's lifetime and needing to have at least one cub of each sex within it's lifetime.

Question 3: Plot attached.
